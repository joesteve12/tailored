import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/notifications/reminder_reconciler.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'core/theme/theme_mode_provider.dart';

void main() {
  runApp(const ProviderScope(child: TailoredApp()));
}

class TailoredApp extends ConsumerWidget {
  const TailoredApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);
    final themeMode = ref.watch(themeModeProvider);
    // Activate the reminder reconciler for the app's lifetime: keeps local
    // notifications matched to the server's reminder set, auth-aware.
    // Watching (not reading) a plain Provider just pins it alive; its
    // create runs once. See core/notifications/reminder_reconciler.dart.
    ref.watch(reminderReconcilerProvider);

    return MaterialApp.router(
      title: 'Tailored',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: themeMode,
      routerConfig: router,
    );
  }
}
